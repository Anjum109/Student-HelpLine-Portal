<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <title>student helpline portal</title>
   <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <div  class="wrapper">
    <div class="Container" >
        <header>
            <img  src="image/logo.jpg" style="height: 40px; padding:4px; margin-left: 4px;  ">
              
                
           <nav>
                    <ul>
                        <li><a href="index.php"><b>HOME</b></a></li>
                        <li><a href=""><b>ABOUT US</b> </a></li>
                        <li><a href=""><b>CONTACT US</b></a></li>
                        <li ><a href="login.php"><b>LOGIN</b></a></li>   
                        <li ><a href="signup.php"><b>SIGNUP</b></a></li> 
                        <li><a href="feedback.php"><b>FEEDBACK</b></a></li>
            
                    </ul>
        
           </nav>
         
    </div>
   
    </header>
    <section>

    </section>
    <footer></footer>
</div>

</body>
</html>