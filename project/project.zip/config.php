<?php
session_start();

$dbc=mysqli_connect("localhost","root","","studenthelpline");

$base_url=  "http://localhost/project/";
$my_email = "sharminbinty41@gmail.com";
?>